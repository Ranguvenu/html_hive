/**
 * Add a create new group modal to the page.
 *
 * @module     local_learningdashboard/learningdashboard
 * @class      learningdashboard
 * @package    local_learningdashboard
 * @copyright  Moodle India
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later 
 */
define(['local_courses/jquery.dataTables', 'jquery', 'core/str', 'core/modal_factory', 'core/modal_events', 'core/fragment', 'core/ajax', 'core/yui', 'core/templates', 'local_learningdashboard/graph'],
    function (dataTable, $, Str, ModalFactory, ModalEvents, Fragment, Ajax, Y, Templates, Graph) {

        /**
        * Constructor
        *
        * @param {object} args
        */
        var learningdashboard = function (args) {
            this.contextid = args.contextid ? args.contextid : 1;
            this.args = args;
            this.tunit = args.tunit;
            this.init(args);
        };

        /**
        * @var {Modal} modal
        * @private
        */
        learningdashboard.prototype.modal = null;

        /**
        * Initialise the class.
        *
        * @param {String} selector used to find triggers for the new group modal.
        * @private
        * @return {Promise}
        */
        learningdashboard.prototype.init = function (args) {
            var self = this;
            var head = {
                key: 'courses', component: 'local_learningdashboard',
            };
            var customstrings = Str.get_strings([head,
                {
                    key: 'squads', component: 'local_learningdashboard'
                },
                {
                    key: 'users', component: 'local_learningdashboard'
                },
                {
                    key: 'instructors', component: 'local_learningdashboard'
                },
                {
                    key: 'reviews', component: 'local_learningdashboard'
                },
                {
                    key: 'gradeshistory', component: 'local_learningdashboard'
                }
            ]);

            return customstrings.then(function (strings) {
                var title = '';
                switch (self.args.callback) {
                    case 'coursespopup':
                        title = strings[0];
                        break;
                    case 'squads':
                        title = strings[1];
                        break;
                    case 'users':
                        title = strings[2];
                        break;
                    case 'instructors':
                        title = strings[3];
                        break;
                    case 'reviews':
                        title = strings[4];
                        break;
                    case 'gradeshistory':
                        title = strings[5];
                        break;
                }

                return ModalFactory.create({
                    type: ModalFactory.types.CANCEL,
                    title: title,
                    body: self.getBody(),
                });
            }).then(function (modal) {
                self.modal = modal;
                self.modal.setLarge();

                self.modal.getRoot().on(ModalEvents.hidden, function () {
                    self.modal.setBody('');
                    self.modal.hide();
                    self.modal.destroy();
                });

                self.modal.getRoot().on(ModalEvents.cancel, function () {
                    self.modal.setBody('');
                    self.modal.hide();
                    self.modal.destroy();
                });

                self.modal.getRoot().on(ModalEvents.bodyRendered, function () {
                    self.dataTableshow(self.tunit);
                });

                self.modal.show();
                return self.modal;
            });
        };

        learningdashboard.prototype.dataTableshow = function (tunit) {
            $.fn.dataTable.ext.errMode = 'none';
            $('.managementpopuptable_details').DataTable({
                'paging': true,
                'filter': true,
                'lengthChange': true,
                'lengthMenu': [
                    [5, 10, 25, 50, 100, -1],
                    [5, 10, 25, 50, 100, 'All']
                ],
                'language': {
                    'emptyTable': 'No Records Found',
                    'paginate': {
                        'previous': '<',
                        'next': '>'
                    }
                },
                'processing': true,
            });
        };

        /**
        * @method getBody
        * @private
        * @return {Promise}
        */
        learningdashboard.prototype.getBody = function () {
            return Fragment.loadFragment(this.args.component, this.args.callback, 1, this.args);
        };

        /**
        * @method getFooter
        * @private
        * @return {Promise}
        */
        learningdashboard.prototype.getFooter = function () {
            return Str.get_strings([{
                key: 'cancel'
            }]).then(function (s) {
                return '<button type="button" class="btn btn-secondary" data-action="cancel">' + s[0] + '</button>';
            });
        };

        /**
        * @method getcontentFooter
        * @private
        * @return {Promise}
        */
        learningdashboard.prototype.getcontentFooter = function () {
            return Str.get_strings([{
                key: 'cancel'
            }]).then(function (s) {
                return '<button type="button" class="btn btn-secondary" data-action="cancel">' + s[0] + '</button>';
            });
        };

        var users = {
            /**
             * Attach event listeners to initialise this module.
             *
             * @method init
             * @param {object} args The arguments for initialization.
             * @return {Promise}
             */
            init: function (args) {
                return new learningdashboard(args);
            },
            Datatable: function () {
                // Functionality for Datatable if needed
            },
            teamsstatus: function () {
                $('.learningdashboard_team_status').DataTable({
                    'paging': true,
                    'filter': true,
                    'lengthChange': false,
                    'pageLength': 5,
                    'language': {
                        'emptyTable': 'No Records Found',
                        'paginate': {
                            'previous': '<',
                            'next': '>'
                        }
                    },
                    'processing': true,
                    'ordering': false,
                });
            },
            creditsdata: function (args) {
                $(document).on('click', '.completed, .pending', function () {
                    creditsview(this);
                });

                function creditsview(obj) {
                    var status = $(obj).hasClass("pending") ? 'pending' : 'completed';
                    $(obj).toggleClass('active');
                    $('.completed, .pending').not(obj).removeClass('active');

                    const params = { status: status };
                    var promise = Ajax.call([{
                        methodname: 'local_learningdashboard_creditsdata_view',
                        args: params,
                        dataType: 'json'
                    }]);

                    $("#creditstables").empty();
                    Templates.render('local_learningdashboard/graph', []).then(function (html) {
                        $('#container').html(html);
                    });

                    promise[0].done(function (resp) {
                        if (resp.totalcount == 0) {
                            $('#creditstables').html('<div class="text-center calendar_events attempt_text"><h4>No Events Available on this Date.</h4></div>');
                        } else {
                            Templates.render('local_learningdashboard/creditsdata_view', resp.records).then(function (html) {
                                $('#creditstables').html(html);
                            });
                        }
                        Graph.init(resp.graphdata);

                        const obj = JSON.parse(resp.records.data);
                        $('head').append(obj.javascript);
                    }).fail(function (ex) {
                        console.log(ex);
                    });
                }
            },
            load: function () {
                // $(".completed").trigger("click");
            }
        };

        return users;
    });

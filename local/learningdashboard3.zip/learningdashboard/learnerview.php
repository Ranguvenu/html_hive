<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * TODO describe file learnerview
 *
 * @package    local_learningdashboard
 * @copyright  2024 YOUR NAME <your@email.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
require('../../config.php');

require_login();

$url = new moodle_url('/local/learningdashboard/learnerview.php');
$PAGE->set_url($url);
$PAGE->set_context(context_system::instance());
$PAGE->set_heading(get_string('learninggoalstatus', 'local_learningdashboard'));

// Sample data for the graph
$sample_data = json_encode([
    "US" => ["1965" => 0, "1966" => 1, "1967" => 2, "1968" => 3, "2020" => 50],
    "UK" => ["1965" => 0.5, "1966" => 1.5, "1967" => 2.5, "1968" => 3.5, "2020" => 60],
    "France" => ["1965" => 0.2, "1966" => 1.2, "1967" => 2.2, "1968" => 3.2, "2020" => 70],
    "Germany" => ["1965" => 0.3, "1966" => 1.3, "1967" => 2.3, "1968" => 3.3, "2020" => 80],
    "Japan" => ["1965" => 0.4, "1966" => 1.4, "1967" => 2.4, "1968" => 3.4, "2020" => 90]
]);

$PAGE->requires->js_call_amd('local_learningdashboard/graph', 'init', [$sample_data]);

echo $OUTPUT->header();
echo $OUTPUT->render_from_template('local_learningdashboard/graph', []);
echo $OUTPUT->footer();

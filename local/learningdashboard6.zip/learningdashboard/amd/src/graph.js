define(['jquery', 'core/str', 'core/ajax', 'local_learningdashboard/js/highcharts'], function($, str, ajax, Highcharts) {

    let dataset, chart, completionPercentage;

    function getData() {
        return [
            ["Completed", dataset.data.Completed],
            ["Pending", dataset.data.Pending]
        ];
    }

    function getSubtitle() {
        return `<span style="font-size: 80px">${completionPercentage}%</span><br><span style="font-size: 22px">Completion Percentage</span>`;
    }

    function update() {
        chart.update({
                subtitle: {
                    text: getSubtitle()
                }
            },
            false,
            false,
            false
        );

        chart.series[0].update({
            name: 'Completion Status',
            data: getData()
        });
    }

    function pause(button) {
        button.title = 'play';
        button.className = 'fa fa-play';
        clearTimeout(chart.sequenceTimer);
        chart.sequenceTimer = undefined;
    }

    function play(button) {
        button.title = 'pause';
        button.className = 'fa fa-pause';
        chart.sequenceTimer = setInterval(function() {
            update();
        }, 500);
    }

    return {
        init: function(data) {
            dataset = JSON.parse(data);
            completionPercentage = dataset.completion_percentage;

            // Now attach event listeners after DOM is loaded and chart is initialized
            const btn = document.getElementById('play-pause-button');
            const input = document.getElementById('play-range');

            if (btn) {
                btn.addEventListener('click', function() {
                    if (chart.sequenceTimer) {
                        pause(this);
                    } else {
                        play(this);
                    }
                });
            }

            if (input) {
                input.addEventListener('input', function() {
                    update();
                });
            }

            // Initialize the chart using Highcharts
            chart = Highcharts.chart('container', {
                title: {
                    text: '',
                    align: 'center'
                },
                subtitle: {
                    useHTML: true,
                    text: getSubtitle(),
                    floating: true,
                    verticalAlign: 'middle',
                    y: 30
                },
                legend: {
                    enabled: false
                },
                tooltip: {
                    valueDecimals: 2,
                    valueSuffix: ' units'
                },
                plotOptions: {
                    pie: {
                        borderWidth: 0,
                        colorByPoint: true,
                        size: '100%',
                        innerSize: '70%',
                        dataLabels: {
                            enabled: true,
                            crop: false,
                            distance: '-20%',
                            style: {
                                fontWeight: 'bold',
                                fontSize: '16px'
                            },
                            connectorWidth: 0
                        },
                        center: ['50%', '50%']
                    }
                },
                colors: ['#4CAF50', '#FFC107'], // Green for completed, yellow for pending
                series: [{
                    type: 'pie',
                    name: 'Completion Status',
                    data: getData()
                }],
                credits: {
                    enabled: false
                }
            });
        }
    };
});

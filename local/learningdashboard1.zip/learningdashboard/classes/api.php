<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace local_learningdashboard;

/**
 * Class api
 *
 * @package    local_learningdashboard
 * @copyright  2024 YOUR NAME <your@email.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class api
{
    public static function creditsinfo($coursestatus = null, $type = null, $viewtype = 'learner', $stable = null) {
        global $DB, $USER, $CFG;
        $select = '';
        $groupby = '';
        $as = '';
        $technicalcategories = $CFG->local_learningdashboard_technical_categories;
        $leadershipcategories = $CFG->local_learningdashboard_leadership_categories;
        $all = $leadershipcategories.','.$technicalcategories;
        if($viewtype == 'manager') {
            $countsql = " SELECT count(userid) FROM (";
            $select = " u.username, u.id as userid,concat(u.firstname, '', u.lastname) as employeename, ";
            $groupby = " GROUP BY u.username,userid,employeename,creditstype,status ";
            $as =" ) as a";
        }
        $selectsql = "SELECT $select GROUP_CONCAT(c.id) as courseids,SUM(c.open_points) as achievedpoints,CASE WHEN ccat.id IN (71,72) then 'Technical' WHEN ccat.id IN (73,74) THEN 'Leadership' end as creditstype,CASE WHEN timecompleted IS NOT NULL then 'Completed' WHEN timecompleted IS  NULL THEN 'Pending' end as status ";
        $sql = "FROM {user} u 
        JOIN {user_enrolments} ue ON ue.userid = u.id
        JOIN {enrol} e ON e.id = ue.enrolid AND  e.enrol = 'manual'
        JOIN {course} c ON c.id=e.courseid
        JOIN {course_categories} ccat ON ccat.id = c.category
        LEFT JOIN {course_completions} cc ON cc.course = c.id AND u.id=cc.userid
        WHERE 1  ";
        if($type == 'Technical'){
            $sql .= " AND ccat.id IN ($leadershipcategories) ";
        }else if($type == 'Leadership'){
            $sql .= "AND ccat.id IN ($technicalcategories) ";
        }else{
            $sql .= "AND ccat.id IN ($all) ";
        }
        $params = [];
        if($coursestatus == 'completed'){
            $sql .= " AND timecompleted IS NOT NULL ";
        }else if($coursestatus == 'pending'){
            $sql .= " AND timecompleted IS NULL ";
        }
        if($viewtype == 'learner'){
            $sql .= " AND u.id = :userid ";
            $params['userid'] = 4106;
            // $params['userid'] = $USER->id;
            return $courses = $DB->get_records_sql($selectsql.$sql.$groupby, $params);
        }else{
            // echo $sql.$groupby;
            $courses = $DB->get_records_sql($selectsql.$sql.$groupby, $params, $stable->start, $stable->length);
            $count = $DB->count_records_sql($countsql.$selectsql.$sql.$groupby.$as, $params, $stable->start, $stable->length);
        }
        return ['count' => $count, 'courses' => $courses];
    }
    public static function targetcreditsinfo($creditstype, $user) {
        global $DB;
        $sql = "SELECT * FROM {local_learningdashboard_master} WHERE months >= :months AND creditstype =:creditstype";
        $joindate = date('Y-m-d', $user->open_doj);
        $today = date('Y-m-d');
        $date1=date_create($joindate);
        $date2=date_create($today);
        $diff=date_diff($date1,$date2);
        $months = $diff->format("%m");
        $targetcredits = $DB->get_record_sql($sql,['months' => $months, 'creditstype' => $creditstype]);
        return $targetcredits;
    }
    public function creditscourseslist() {
        global $DB;
    }
}

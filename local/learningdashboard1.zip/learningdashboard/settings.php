<?php

/**
 * This file is part of eAbyas
 *
 * Copyright eAbyas Info Solutons Pvt Ltd, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @author eabyas  <info@eabyas.in>
 * @package BizLMS
 * @subpackage local_forum
 */

defined('MOODLE_INTERNAL') || die;
global $DB;
require_once($CFG->dirroot.'/local/learningdashboard/lib.php');
if ($hassiteconfig) {
    $settings = new admin_settingpage('local_learningdashboard', get_string('pluginname', 'local_learningdashboard'));
    $ADMIN->add('localplugins', $settings);
    // Default Read Tracking setting.
    $options = array(get_string('pleaseselecttechnicalcategories', 'local_learningdashboard'));
    $sql = "SELECT id, name FROM {course_categories} WHERE id > 1 ";
    $categories = course_categories_list();
    $settings->add(new admin_setting_configmultiselect(
        'local_learningdashboard_technical_categories',
        get_string('technical_categories', 'local_learningdashboard'),
        get_string('technical_categories', 'local_learningdashboard'),
        [],
         $categories
    ));
    $options = array(get_string('pleaseselectleadershipcategories', 'local_learningdashboard'));
    $settings->add(new admin_setting_configmultiselect(
        'local_learningdashboard_leadership_categories',
        get_string('leadership_categories', 'local_learningdashboard'),
        get_string('leadership_categories', 'local_learningdashboard'),
        [],
        $categories
    ));
}

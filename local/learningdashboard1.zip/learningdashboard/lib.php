<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Callback implementations for Learning Dashboard
 *
 * @package    local_learningdashboard
 * @copyright  2024 YOUR NAME <your@email.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

use local_learningdashboard\api;

/**
 * Serve the table for course status
 *
 * @param array $args List of named arguments for the fragment loader.
 * @return string
 */
function local_learningdashboard_output_fragment_coursespopup($args)
{
    global $DB, $CFG, $PAGE, $OUTPUT, $USER;
    $args['courseids'];
    $coursedata = array();
    $sql = "SELECT c.id,c.fullname, c.open_points FROM {course} c
    WHERE 1 ";
    $courseidsarr = explode(',',$args['courseids']);
    list($concatsql, $params) = $DB->get_in_or_equal($courseidsarr, SQL_PARAMS_NAMED);
    $sql .= " AND c.id $concatsql ";
    $courses = $DB->get_records_sql($sql, $params);
    foreach ($courses as $key => $course) {
        $coursedata['courseid'] = $course->id;
        $coursedata['coursename'] = $course->fullname;
        $coursedata['achievedcredits'] = $course->open_points;
        $coursedata['creditstype'] = 'Technical';
        $coursedataarr[] = $coursedata;
    }
    $finaladmindashboard = [
        'coursedetails' => $coursedataarr,
        'creditsstatus' => ($args['creditsstatus'] == 'completed') ? get_string('achievedcredits', 'local_learningdashboard') : get_string('pendingcredits', 'local_learningdashboard')
    ];
    $args['regid'] = 1;
    $output = $OUTPUT->render_from_template('local_learningdashboard/coursespopup', $finaladmindashboard);
    return $output;
}
function mylearningsdata($coursestatus)
{
    global $CFG, $OUTPUT, $PAGE;
    // print_r($targetcreditsinfo);exit;
    $admindashboardarr = [];
    $admindashboard = array();
    $creditstypearray = ['Technical', 'Leadership'];
    $completedtab = $coursestatus == 'completed' ? 1 : 0;
    $pendingtab = $coursestatus == 'pending' ? 1 : 0;
    $totaltargetcredits = 0;
    $totalachievedcredits = 0;
    foreach ($creditstypearray as $type) {
        $user = \core_user::get_user_by_username('admin');
        $targetcreditsinfo = api::targetcreditsinfo($type, $user);
        $courses = api::creditsinfo($coursestatus, $type);
        $admindashboard['targetcredits'] = $targetcreditsinfo->credits;
        if ($coursestatus == 'pending')
            $admindashboard['pendingcredits'] = $courses->achievedpoints ? $courses->achievedpoints : 0;
        else
            $admindashboard['achievedcredits'] = $courses->achievedpoints ? $courses->achievedpoints : 0;
        $admindashboard['creditstype'] =  $type . ' Credits';
        // $admindashboard['ismanagerview'] = true;
        $admindashboard['courseids'] = $courses->courseids;
        $admindashboard['coursestatus'] = $coursestatus;
        $totaltargetcredits += $targetcreditsinfo->credits;
        $totalachievedcredits += $courses->achievedpoints;
        // $admindashboard['renderchart'] = $chart2;
        $admindashboardarr[] = $admindashboard;
    }
    $completedperc = $totalachievedcredits / $totaltargetcredits * 100;
    $pendingperc = 100 - $completedperc;
    $sales = new \core\chart_series('Completed', [round($pendingperc), round($completedperc)]);
    $labels = ['Target credits',  ucfirst($coursestatus).' credits'];
    $chart2 = new \core\chart_pie();
    $chart2->set_title('DOUGHNUT CHART');
    $chart2->set_doughnut(true);
    $chart2->add_series($sales);
    $chart2->set_labels($labels);
    $CFG->chart_colorset = ['#3498DB', '#F4D03F'];
    // $renderchart = $OUTPUT->render($chart2);
    $OUTPUT->header();
    $PAGE->start_collecting_javascript_requirements();
    $o = '';
    ob_start();
    $o .= $OUTPUT->render_chart($chart2, false);
    $o .= ob_get_contents();
    ob_end_clean();
    $data = $o;
    $jsfooter = $PAGE->requires->get_end_code();
    $output = [];
    $output['error'] = false;
    $output['javascript'] = $jsfooter;

    return ['learnerdata' => $admindashboardarr, 'completedtab' => $completedtab, 'pendingtab' => $pendingtab, 'data' => json_encode($output), 'charthtml' => $data,'islearnerview' =>true];
}
function course_categories_list()
{
    global $DB;
    $parentcategory = $DB->get_field('local_costcenter', 'category', array('id' => 1));
    $categorysql = "SELECT cc.id, cc.path 
                          FROM {course_categories} AS cc 
                          WHERE (cc.path LIKE '%/{$parentcategory}/%' ";
    if ($parentcategory) {
        $categorysql .= " OR cc.id = {$parentcategory} ";
    }
    $categorysql .= " ) ORDER BY cc.sortorder ASC ";
    $displaylist = $DB->get_records_sql_menu($categorysql);
    if (isset($displaylist) && !empty($displaylist)) {
        $findisplaylist = array();
        foreach ($displaylist as $key => $categorywise) {
            $explodepaths = explode('/', $categorywise);
            $countcat = count($explodepaths);
            if ($countcat > 0) {
                $catpathnames = array();
                for ($i = 0; $i < $countcat; $i++) {
                    if ($i != 0) {
                        $catpathnames[$i] = $DB->get_field('course_categories', 'name', array('id' => $explodepaths[$i]));
                    }
                }
                if (count($catpathnames) > 1) {
                    $findisplaylist[$key] = implode(' / ', $catpathnames);
                } else {
                    $findisplaylist[$key] = $catpathnames[1];
                }
            }
        }
        $categories =  $findisplaylist;
    } else {
        $categories = [];
    }
    return $categories;
}
function teamslearningsdata($stable)
{
    global $CFG, $OUTPUT, $PAGE;
    // print_r($targetcreditsinfo);exit;
    $admindashboardarr = [];
    $admindashboard = array();
    $totaltargetcredits = 0;
    $totalachievedcredits = 0;
    $teamsstatus = api::creditsinfo(null, null, 'manager', $stable);
    foreach ($teamsstatus['courses'] as $teamuser) {
        $user = \core_user::get_user_by_username($teamuser->username);
        $targetcreditsinfo = api::targetcreditsinfo($teamuser->creditstype, $user);
        $admindashboard['targetcredits'] = $targetcreditsinfo->credits;
        $admindashboard['achievedcredits'] = $teamuser->achievedpoints ? $teamuser->achievedpoints : 0;
        $admindashboard['creditstype'] =  $teamuser->creditstype . ' Credits';
        $admindashboard['courseids'] = $teamuser->courseids;
        $admindashboard['coursestatus'] = $teamuser->status;
        $admindashboard['username'] = $teamuser->status;
        $admindashboard['employeename'] = $teamuser->employeename;
        $admindashboard['ismanagerview'] = true;
        $totaltargetcredits += $targetcreditsinfo->credits;
        $totalachievedcredits += $teamuser->achievedpoints;
        // $admindashboard['renderchart'] = $chart2;
        $admindashboardarr[] = $admindashboard;
    }
    return ['records' => $admindashboardarr,'ismanagerview' => true, 'count' => $teamsstatus['count']];
}

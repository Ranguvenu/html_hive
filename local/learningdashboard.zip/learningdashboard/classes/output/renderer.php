<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace local_learningdashboard\output;

/**
 * Class learningdashboard
 *
 * @package    local_learningdashboard
 * @copyright  2024 YOUR NAME <your@email.com>
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

 use plugin_renderer_base;

 class pluginname_renderer extends plugin_renderer_base {
    public function render_graph() {
        $content = '';
        $content .= '<canvas id="learningGoalChart" width="400" height="400"></canvas>';

        // Add JavaScript for generating the chart
        $content .= '<script>
            var ctx = document.getElementById("learningGoalChart").getContext("2d");
            var learningGoalChart = new Chart(ctx, {
                type: "doughnut",
                data: {
                    labels: ["Completed", "Pending"],
                    datasets: [{
                        label: "Learning Goal Status",
                        data: [75, 25], // Replace 75 with dynamic PHP value for completed percentage
                        backgroundColor: [
                            "#FFCE56", // Yellow for completed
                            "#36A2EB"  // Blue for pending
                        ],
                        hoverOffset: 4
                    }]
                },
                options: {
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: function(tooltipItem) {
                                    return tooltipItem.label + ": " + tooltipItem.raw + "%";
                                }
                            }
                        }
                    },
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: "70%", // Creates the donut hole
                    elements: {
                        center: {
                            text: "75%", // Dynamic value for percentage
                            color: "#36A2EB", // Font color
                            fontStyle: "Arial", // Font family
                            sidePadding: 20 // Padding around the text
                        }
                    }
                }
            });
        </script>';

        return $content;
    }
}

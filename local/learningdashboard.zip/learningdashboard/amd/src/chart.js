// define(['jquery', 'core/str', 'chartjs'], function($, str, Chart) {
//     return {
//         init: function() {
//             var ctx = document.getElementById('learningGoalChart').getContext('2d');
//             var learningGoalChart = new Chart(ctx, {
//                 type: 'doughnut',
//                 data: {
//                     labels: ['Completed', 'Pending'],
//                     datasets: [{
//                         label: 'Learning Goal Status',
//                         data: [75, 25], // Static data; can be replaced with dynamic PHP data
//                         backgroundColor: ['#FFCE56', '#36A2EB'],
//                         hoverOffset: 4
//                     }]
//                 },
//                 options: {
//                     plugins: {
//                         tooltip: {
//                             callbacks: {
//                                 label: function(tooltipItem) {
//                                     return tooltipItem.label + ": " + tooltipItem.raw + "%";
//                                 }
//                             }
//                         }
//                     },
//                     responsive: true,
//                     maintainAspectRatio: false,
//                     cutout: '70%',
//                     elements: {
//                         center: {
//                             text: '75%',  // Dynamic text can be passed here from PHP
//                             color: '#36A2EB',  // Font color
//                             fontStyle: 'Arial',  // Font family
//                             sidePadding: 20
//                         }
//                     }
//                 }
//             });
//         }
//     };
// });


define(['jquery', 'core/str', 'chartjs'], function($, str, Chart) {
    return {
        init: function() {
            var ctx = document.getElementById('learningGoalChart').getContext('2d');
            var learningGoalChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Completed', 'Pending'],
                    datasets: [{
                        label: 'Learning Goal Status',
                        data: [75, 25], // Static data; you can replace with dynamic data from PHP
                        backgroundColor: ['#FFCE56', '#36A2EB'],
                        hoverOffset: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    cutout: '70%',
                }
            });
        }
    };
});

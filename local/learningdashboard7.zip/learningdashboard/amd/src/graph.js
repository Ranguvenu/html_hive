define(['jquery', 'core/str', 'core/ajax', 'highcharts'], function($, str, ajax, Highcharts) {
    let dataset, chart, completionPercentage;

    function getData() {
        console.log("dataset dataset dataset:", dataset.data);
        return [
            ["Completed", dataset.data.Completed],
            ["Pending", dataset.data.Pending]
        ];
    }

    function getSubtitle() {
        return `<span style="font-size: 80px">${completionPercentage}%</span><br><span style="font-size: 22px">Completion Percentage</span>`;
    }

    function update() {
        chart.update({
            subtitle: {
                text: getSubtitle()
            }
        });

        chart.series[0].update({
            name: 'Completion Status',
            data: getData()
        });
    }

    return {
        init: function(data) {
            dataset = JSON.parse(data);
            completionPercentage = dataset.completion_percentage;

            chart = Highcharts.chart('container', {
                title: {
                    text: '',
                    align: 'right'
                },
                subtitle: {
                    useHTML: true,
                    text: getSubtitle(),
                    floating: true,
                    verticalAlign: 'middle',
                    y: 30
                },
                legend: {
                    enabled: false
                },
                tooltip: {
                    valueDecimals: 2,
                    valueSuffix: ' units'
                },
                plotOptions: {
                    pie: {
                        borderWidth: 0,
                        colorByPoint: true,
                        size: '100%',
                        innerSize: '70%',
                        dataLabels: {
                            enabled: true,
                            crop: false,
                            distance: '-20%',
                            style: {
                                fontWeight: 'bold',
                                fontSize: '5px'
                            },
                            connectorWidth: 0
                        },
                        center: ['50%', '50%']
                    }
                },
                colors: ['#4CAF50', '#FFC107'], // Green for completed, yellow for pending
                series: [{
                    type: 'pie',
                    name: 'Completion Status',
                    data: getData()
                }],
                credits: {
                    enabled: false
                }
            });

            // Optional: Call update() here if you need to make any initial updates to the chart
            // update();
        }
    };
});

<?php
/**
 * This file is part of eAbyas
 *
 * Copyright eAbyas Info Solutons Pvt Ltd, India
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @author eabyas  <info@eabyas.in>
 * @package BizLMS
 * @subpackage local_learningplan
 */
defined('MOODLE_INTERNAL') || die;

use local_learningdashboard;
require_once('../../config.php');
require_once($CFG->libdir . '/csvlib.class.php');

function download_csv($data, $filename = 'report') {
    $csvexport = new csv_export_writer();
    $csvexport->set_filename($filename);

    $headers = ['Completed status', 'Employee status', 'Employee email', 'Completion Grade', 'Employee department', 'Course Name', 'Course Credits',
    'Username', "Course Category", "Credit Category", "Learnig Type", "Enrollment Date", "Completion Date"];
    $csvexport->add_data($headers);

    foreach ($data as $row) {
        $csvexport->add_data([
            $row->completedstatus ?? '--',
            $row->employeestatus ?? '--',
            $row->employeeemail ?? '--',
            $row->completiongrade ?? '--',
            $row->employeedepartment ?? '--',
            $row->coursename ?? '--',
            $row->coursecredits ?? '--',
            $row->username ?? '--',
            $row->coursecategory ?? '--',
            $row->creditcategory ?? '--',
            $row->learningtype ?? '--',
            $row->enrolmentdate ?? '--',
            $row->completiondate ?? '--'
        ]);
    }
    $csvexport->download_file();
    exit();
}

function reportdata($viewtype){
    global $DB, $CFG, $USER;
    $systemcontext = context_system::instance();
    $technicalcategories = $CFG->local_learningdashboard_technical_categories;
    $leadershipcategories = $CFG->local_learningdashboard_leadership_categories;
    $all = $technicalcategories . ', ' . $leadershipcategories;

    $userid = false;
    $sql = " SELECT
                lc.id AS ccourseid,
                u.id AS uuserid,
                c.fullname,
                cc.timecompleted AS forstatus,
                ue.timecreated,
                cc.timecompleted AS fordate,
                lc.credits AS coursecredits,
                ccat.idnumber AS coursecategoryid,
                lc.grade,
                lu.grade,
                u.department,
                u.email,
                u.username,
                ccat.name AS coursecategory,
                lcc.fullname AS learningtype,
                CASE
                    WHEN ccat.id IN ($leadershipcategories) THEN 'Leadership'
                    WHEN ccat.id IN ($technicalcategories) THEN 'Technical'
                END AS creditcategory
            FROM {local_coursedetails} lc
            JOIN {course} c ON c.id = lc.courseid
            JOIN {enrol} e ON e.courseid = lc.courseid
            JOIN {user_enrolments} ue ON ue.enrolid = e.id
            JOIN {user} u ON u.id = ue.userid
            JOIN {local_userdata} lu ON lu.userid = u.id
            JOIN {local_course_types} lct ON lct.id = c.open_identifiedas
            JOIN {course_categories} ccat ON ccat.id = c.category
            JOIN {local_costcenter} lcc ON lcc.id = u.open_departmentid
            LEFT JOIN {course_completions} cc ON cc.course = lc.courseid
            WHERE ccat.id IN ($all) ";

    $sql .= ($viewtype == 'self' || $viewtype == 'student') ? " AND u.id = :userid " : "";

    if ($viewtype == 'manager') {
        $sql .= " AND u.id IN (:userids) ";
        $params['userids'] = local_learningdashboard\api::teamusers();
    } elseif ($viewtype == 'admin') {
        if (!is_siteadmin()) {
            $sql .= " AND u.open_costcenterid = :costcenterid ";
            $params['costcenterid'] = $USER->open_costcenterid;
        }
    }

    $params = ['userid' => $userid];
    $records = $DB->get_records_sql($sql, $params);
        $reportarray = array();
    foreach($records as $record){
        $columns = new stdClass();
        $columns->completedstatus = $record->timecompleted ? get_string('completed', 'block_configurable_reports') : get_string('inprogress', 'block_configurable_reports');
        if ($record->deleted == 0 && $record->deleted == 0){
            $columns->employeestatus = get_string('active', 'block_configurable_reports');
        }else{
            $columns->employeestatus = get_string('inactive', 'block_configurable_reports');
        }
        $columns->completiondate  = date('d-m-Y', $record->timecompleted);
        $columns->employeeemail  = $record->email;
        $columns->completiongrade  = $record->grade;
        $columns->employeedepartment  = $record->department ? $record->department : "--";
        $columns->coursename  = $record->fullname;
        $columns->coursecredits  = $record->coursecredits;
        $columns->username  = $record->username;
        $columns->coursecategory  = $record->coursecategory;
        $columns->enrolmentdate  = date('d-m-Y', $record->timecreated);
        $columns->creditcategory  = $record->creditcategory;
        $columns->coursecategory  = $record->coursecategory;
        $columns->learningtype  = $record->learningtype;
        $reportarray[] = $columns;
    }
    return $reportarray;
}
$view = optional_param('view', null, PARAM_TEXT);
$reportarray = reportdata($view);
download_csv($reportarray);


